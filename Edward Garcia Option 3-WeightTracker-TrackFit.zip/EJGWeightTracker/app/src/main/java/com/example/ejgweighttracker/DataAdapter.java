package com.example.ejgweighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private final List<WeightEntry> weightEntries;
    private final OnDeleteClickListener onDeleteClickListener;

    // Interface to handle delete button clicks
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    // Constructor to initialize the weight entries list and delete click listener
    public DataAdapter(List<WeightEntry> weightEntries, OnDeleteClickListener onDeleteClickListener) {
        this.weightEntries = weightEntries;
        this.onDeleteClickListener = onDeleteClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item in the RecyclerView
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind the data to the ViewHolder
        WeightEntry entry = weightEntries.get(holder.getAdapterPosition());
        holder.weightTextView.setText(entry.getWeight());
        holder.dateTextView.setText(entry.getDate());
        holder.deleteButton.setOnClickListener(v -> onDeleteClickListener.onDeleteClick(holder.getAdapterPosition()));
    }

    @Override
    public int getItemCount() {
        // Return the total number of items in the list
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView;
        TextView dateTextView;
        Button deleteButton;

        // ViewHolder constructor to initialize the views
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weight_text);
            dateTextView = itemView.findViewById(R.id.date_text);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
