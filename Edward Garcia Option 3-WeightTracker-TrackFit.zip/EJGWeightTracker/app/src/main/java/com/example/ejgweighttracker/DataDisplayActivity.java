package com.example.ejgweighttracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private EditText weightInput;
    private EditText dateInput;
    private DataAdapter dataAdapter;
    private List<WeightEntry> weightEntries;
    private DatabaseHelper dbHelper;
    private TextView goalWeightText;
    private String goalWeight;
    private EditText newGoalWeightInput;

    private static final String CHANNEL_ID = "weight_goal_channel";
    private static final int NOTIFICATION_REQUEST_CODE = 1;
    private static final int SMS_PERMISSION_REQUEST_CODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        weightInput = findViewById(R.id.weight_input);
        dateInput = findViewById(R.id.date_input);
        Button addDataButton = findViewById(R.id.add_data_button);
        RecyclerView dataGrid = findViewById(R.id.data_grid);
        goalWeightText = findViewById(R.id.goal_weight_text);
        newGoalWeightInput = findViewById(R.id.new_goal_weight_input);
        Button updateGoalWeightButton = findViewById(R.id.update_goal_weight_button);
        Button logoutButton = findViewById(R.id.logout_button);
        dbHelper = new DatabaseHelper(this);

        // Load goal weight from the database for the current user
        long userId = getCurrentUserId();  // Get the current user ID from SharedPreferences
        double goalWeightValue = dbHelper.getGoalWeight(userId);
        goalWeight = goalWeightValue == -1 ? "" : String.valueOf(goalWeightValue);
        goalWeightText.setText(getString(R.string.goal_weight_text_with_lbs, goalWeight));

        // Initialize weight entries list and data adapter
        weightEntries = new ArrayList<>();
        dataAdapter = new DataAdapter(weightEntries, this::deleteWeightEntry);

        // Set RecyclerView
        dataGrid.setLayoutManager(new LinearLayoutManager(this));
        dataGrid.setAdapter(dataAdapter);

        // Set onClickListeners for buttons
        addDataButton.setOnClickListener(v -> addWeightEntry());
        updateGoalWeightButton.setOnClickListener(v -> updateGoalWeight());
        logoutButton.setOnClickListener(v -> logout());

        // Load existing weight entries from the database
        loadWeightEntries();

        // Create notification channel
        createNotificationChannel();
    }

    // Method to add a new weight entry
    private void addWeightEntry() {
        String weightStr = weightInput.getText().toString();
        String dateStr = dateInput.getText().toString();
        double weight = Double.parseDouble(weightStr);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Get the current user ID
        long userId = getCurrentUserId();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USER_ID, userId);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);
        values.put(DatabaseHelper.COLUMN_DATE, dateStr);

        long newRowId = db.insert(DatabaseHelper.TABLE_DAILY_WEIGHTS, null, values);
        if (newRowId != -1) {
            WeightEntry entry = new WeightEntry(weightStr, dateStr);
            weightEntries.add(entry);
            dataAdapter.notifyItemInserted(weightEntries.size() - 1);
            weightInput.setText("");
            dateInput.setText("");

            // Hide the keyboard
            View view = this.getCurrentFocus();
            if (view != null) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }

            // Show Toast message
            Toast.makeText(this, "Daily Weight Added", Toast.LENGTH_SHORT).show();

            // Check if goal weight is reached exactly
            double goalWeightValue = Double.parseDouble(goalWeight);
            if (goalWeightValue != -1 && weight == goalWeightValue) {
                sendGoalReachedNotification();
                sendGoalReachedSms();
            }
        }
    }

    // Method to load existing weight entries from the database
    @SuppressLint("NotifyDataSetChanged")
    private void loadWeightEntries() {
        long userId = getCurrentUserId(); // Get the current user ID

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {
                DatabaseHelper.COLUMN_WEIGHT,
                DatabaseHelper.COLUMN_DATE
        };
        String selection = DatabaseHelper.COLUMN_USER_ID + "=?"; // Filter by user ID
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query(DatabaseHelper.TABLE_DAILY_WEIGHTS, columns, selection, selectionArgs, null, null, null);
        while (cursor.moveToNext()) {
            String weight = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));
            WeightEntry entry = new WeightEntry(weight, date);
            weightEntries.add(entry);
        }
        cursor.close();
        dataAdapter.notifyDataSetChanged();
    }

    // Method to delete a weight entry
    private void deleteWeightEntry(int position) {
        WeightEntry entry = weightEntries.get(position);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = DatabaseHelper.COLUMN_DATE + "=? AND " + DatabaseHelper.COLUMN_WEIGHT + "=?";
        String[] selectionArgs = {entry.getDate(), entry.getWeight()};

        int deletedRows = db.delete(DatabaseHelper.TABLE_DAILY_WEIGHTS, selection, selectionArgs);
        if (deletedRows > 0) {
            weightEntries.remove(position);
            dataAdapter.notifyItemRemoved(position);
            Toast.makeText(this, "Weight entry deleted", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to create notification channel
    private void createNotificationChannel() {
        CharSequence name = "Weight Goal Channel";
        String description = "Channel for weight goal notifications";
        int importance = NotificationManager.IMPORTANCE_DEFAULT;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);
    }

    // Method to send goal reached notification
    private void sendGoalReachedNotification() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST_CODE);
            return;
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification) // Ensure you have an icon named ic_notification in your drawable folder
                .setContentTitle(getString(R.string.goal_reached_notification_title))
                .setContentText(getString(R.string.goal_reached_notification_text))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.notify(1, builder.build());
    }

    // Method to send goal reached SMS
    private void sendGoalReachedSms() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            sendSms();
        }
    }

    // Method to send SMS
    private void sendSms() {
        String phoneNumber = "(650) 555-1212";
        String message = getString(R.string.goal_reached_sms_message, goalWeight);
        SmsManager smsManager = getSystemService(SmsManager.class);
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, getString(R.string.sms_sent), Toast.LENGTH_SHORT).show();
    }

    // Method to update goal weight
    private void updateGoalWeight() {
        String newGoalWeightStr = newGoalWeightInput.getText().toString();
        if (newGoalWeightStr.isEmpty()) {
            Toast.makeText(this, "Please enter a new goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        long userId = getCurrentUserId();  // Get the current user ID
        goalWeight = newGoalWeightStr;
        goalWeightText.setText(getString(R.string.goal_weight_text_with_lbs, goalWeight));
        dbHelper.setGoalWeight(userId, Double.parseDouble(newGoalWeightStr));  // Save the goal weight for the current user
        newGoalWeightInput.setText("");  // Clear the input field after updating the goal weight

        // Hide the keyboard
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        Toast.makeText(this, "Goal weight updated", Toast.LENGTH_SHORT).show();
    }

    // Method to log out and return to login activity
    private void logout() {
        // Clear user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Clear the stored user ID
        editor.apply();

        Intent intent = new Intent(DataDisplayActivity.this, LoginActivity.class);
        startActivity(intent);
        finish(); // Close the DataDisplayActivity
        Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();
    }

    // Method to get the current user ID
    private long getCurrentUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        return sharedPreferences.getLong("user_id", -1); // -1 means no user ID found
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSms();
            } else {
                Toast.makeText(this, getString(R.string.sms_permission_denied), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
