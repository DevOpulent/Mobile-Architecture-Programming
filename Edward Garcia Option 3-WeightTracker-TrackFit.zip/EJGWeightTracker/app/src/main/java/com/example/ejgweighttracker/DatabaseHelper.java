package com.example.ejgweighttracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 2;

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_DAILY_WEIGHTS = "daily_weights";
    public static final String TABLE_GOAL_WEIGHT = "goal_weight";

    // Common column names
    public static final String COLUMN_ID = "id";

    // USERS Table - column names
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // DAILY_WEIGHTS Table - column names
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";

    // GOAL_WEIGHT Table - column names
    public static final String COLUMN_USER_ID_GOAL = "user_id";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    // Table create statements
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USERNAME + " TEXT,"
            + COLUMN_PASSWORD + " TEXT" + ")";

    private static final String CREATE_TABLE_DAILY_WEIGHTS = "CREATE TABLE " + TABLE_DAILY_WEIGHTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_ID + " INTEGER,"
            + COLUMN_WEIGHT + " REAL,"
            + COLUMN_DATE + " TEXT,"
            + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + ")" + ")";

    private static final String CREATE_TABLE_GOAL_WEIGHT = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_ID_GOAL + " INTEGER,"
            + COLUMN_GOAL_WEIGHT + " REAL,"
            + "FOREIGN KEY(" + COLUMN_USER_ID_GOAL + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + ")" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_DAILY_WEIGHTS);
        db.execSQL(CREATE_TABLE_GOAL_WEIGHT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_GOAL_WEIGHT + " ADD COLUMN " + COLUMN_USER_ID_GOAL + " INTEGER;");
        }

    }

    // Method to set goal weight for a specific user
    public void setGoalWeight(long userId, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID_GOAL, userId);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        if (getGoalWeight(userId) != -1) {
            db.update(TABLE_GOAL_WEIGHT, values, COLUMN_USER_ID_GOAL + "=?", new String[]{String.valueOf(userId)});
        } else {
            db.insert(TABLE_GOAL_WEIGHT, null, values);
        }
    }

    // Method to get the goal weight for a specific user
    public double getGoalWeight(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOAL_WEIGHT, new String[]{COLUMN_GOAL_WEIGHT},
                COLUMN_USER_ID_GOAL + "=?", new String[]{String.valueOf(userId)},
                null, null, null);
        if (cursor.moveToFirst()) {
            double goalWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_GOAL_WEIGHT));
            cursor.close();
            return goalWeight;
        }
        cursor.close();
        return -1; // Return -1 if no goal weight is set for this user
    }
}
