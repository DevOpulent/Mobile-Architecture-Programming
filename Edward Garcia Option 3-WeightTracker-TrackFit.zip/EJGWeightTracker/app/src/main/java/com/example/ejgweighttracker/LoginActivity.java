package com.example.ejgweighttracker;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseHelper dbHelper;

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        Button createNewLoginButton = findViewById(R.id.create_new_login_button);
        dbHelper = new DatabaseHelper(this);

        // Set click listeners for buttons
        loginButton.setOnClickListener(v -> login());
        createNewLoginButton.setOnClickListener(v -> createNewLogin());
    }

    // Method to handle login
    private void login() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Check if the user exists in the database
        String[] columns = {DatabaseHelper.COLUMN_ID};
        String selection = DatabaseHelper.COLUMN_USERNAME + "=? AND " + DatabaseHelper.COLUMN_PASSWORD + "=?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            // Successful login
            long userId = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
            SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putLong("user_id", userId);  // Save the user ID in SharedPreferences
            editor.apply();

            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            cursor.close();

            // Request SMS permission
            if (ContextCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(LoginActivity.this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            } else {
                navigateToDataDisplayActivity();
            }
        } else {
            // Invalid login credentials
            Toast.makeText(this, "No account found! Please create an account.", Toast.LENGTH_SHORT).show();
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    // Method to handle new user registration
    private void createNewLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Insert new user into the database
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, password);

        long newRowId = db.insert(DatabaseHelper.TABLE_USERS, null, values);
        if (newRowId != -1) {
            // Account created successfully
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
        } else {
            // Error creating account
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to navigate to the data display activity
    private void navigateToDataDisplayActivity() {
        Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
        startActivity(intent);
        finish(); // Optional: Close the LoginActivity
    }

    // Handle the result of permission requests
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                navigateToDataDisplayActivity();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission is required to proceed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
