package com.example.ejgweighttracker;

public class WeightEntry {
    private final String weight;
    private final String date;

    // Constructor to initialize weight and date
    public WeightEntry(String weight, String date) {
        this.weight = weight;
        this.date = date;
    }

    // Getter method for weight
    public String getWeight() {
        return weight;
    }

    // Getter method for date
    public String getDate() {
        return date;
    }
}
